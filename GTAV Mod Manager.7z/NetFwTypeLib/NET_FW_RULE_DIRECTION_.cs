﻿// Decompiled with JetBrains decompiler
// Type: NetFwTypeLib.NET_FW_RULE_DIRECTION_
// Assembly: GTAV Mod Manager, Version=1.0.6379.16959, Culture=neutral, PublicKeyToken=null
// MVID: 4020FBC2-BCD0-401F-AC8F-734276BE45A6
// Assembly location: C:\Users\User\Desktop\GTAV Mod Manager.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
  [TypeIdentifier("58fbcf7c-e7a9-467c-80b3-fc65e8fcca08", "NetFwTypeLib.NET_FW_RULE_DIRECTION_")]
  [CompilerGenerated]
  public enum NET_FW_RULE_DIRECTION_
  {
    NET_FW_RULE_DIR_IN = 1,
    NET_FW_RULE_DIR_OUT = 2,
    NET_FW_RULE_DIR_MAX = 3,
  }
}
