﻿// Decompiled with JetBrains decompiler
// Type: NetFwTypeLib.NET_FW_ACTION_
// Assembly: GTAV Mod Manager, Version=1.0.6379.16959, Culture=neutral, PublicKeyToken=null
// MVID: 4020FBC2-BCD0-401F-AC8F-734276BE45A6
// Assembly location: C:\Users\User\Desktop\GTAV Mod Manager.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace NetFwTypeLib
{
  [CompilerGenerated]
  [TypeIdentifier("58fbcf7c-e7a9-467c-80b3-fc65e8fcca08", "NetFwTypeLib.NET_FW_ACTION_")]
  public enum NET_FW_ACTION_
  {
    NET_FW_ACTION_BLOCK,
    NET_FW_ACTION_ALLOW,
    NET_FW_ACTION_MAX,
  }
}
