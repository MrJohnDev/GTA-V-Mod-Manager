﻿// Decompiled with JetBrains decompiler
// Type: GTAV_Mod_Manager.Properties.Resources
// Assembly: GTAV Mod Manager, Version=1.0.6379.16959, Culture=neutral, PublicKeyToken=null
// MVID: 4020FBC2-BCD0-401F-AC8F-734276BE45A6
// Assembly location: C:\Users\User\Desktop\GTAV Mod Manager.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace GTAV_Mod_Manager.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) GTAV_Mod_Manager.Properties.Resources.resourceMan, (object) null))
          GTAV_Mod_Manager.Properties.Resources.resourceMan = new ResourceManager("GTAV_Mod_Manager.Properties.Resources", typeof (GTAV_Mod_Manager.Properties.Resources).Assembly);
        return GTAV_Mod_Manager.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => GTAV_Mod_Manager.Properties.Resources.resourceCulture;
      set => GTAV_Mod_Manager.Properties.Resources.resourceCulture = value;
    }
  }
}
