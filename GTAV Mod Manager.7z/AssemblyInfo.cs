﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: ComVisible(false)]
[assembly: AssemblyTitle("GTAV Mod Manager 2.0")]
[assembly: AssemblyCopyright("Copyright © 2022")]
// [assembly: Extension]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("GTAV Mod Manager 2.0")]
[assembly: AssemblyVersion("2.0.0.0")]
